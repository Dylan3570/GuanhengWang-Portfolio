import UIKit
import CoreData

class FavoritesTableViewController: UITableViewController {
    
    var favorites: [Favorite] = []
    let coreDataManager = CoreDataManager.shared
    
    // Container for the empty-state view
    private var emptyStateStackView: UIStackView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Favorites"
        
        // Set up the gradient background and pull-to-refresh, similar to PeopleTableViewController
        setupUI()
        
        // Set up the empty-state overlay
        setupEmptyStateOverlay()
        
        // Clear-all button on the right side of the navigation bar
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .trash,
            target: self,
            action: #selector(clearAllFavorites)
        )
        navigationItem.rightBarButtonItem?.tintColor = UIColor(
            red: 100/255, green: 180/255, blue: 150/255, alpha: 1.0
        )
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Refresh the list each time the view appears
        fetchFavoritesFromCoreData()
    }
    
    // MARK: - UI: Gradient background + Pull-to-refresh
    
    private func setupUI() {
        // 1) Pink → Light Green gradient
        let backgroundGradient = CAGradientLayer()
        backgroundGradient.colors = [
            UIColor(red: 255/255, green: 160/255, blue: 180/255, alpha: 1.0).cgColor,
            UIColor(red: 160/255, green: 250/255, blue: 210/255, alpha: 1.0).cgColor
        ]
        backgroundGradient.startPoint = CGPoint(x: 0, y: 0)
        backgroundGradient.endPoint = CGPoint(x: 1, y: 1)
        backgroundGradient.frame = view.bounds
        
        let bgView = UIView(frame: view.bounds)
        bgView.layer.insertSublayer(backgroundGradient, at: 0)
        tableView.backgroundView = bgView
        
        // 2) Pull-to-refresh
        refreshControl = UIRefreshControl()
        refreshControl?.tintColor = UIColor(red: 255/255, green: 100/255, blue: 150/255, alpha: 1.0)
        refreshControl?.addTarget(self, action: #selector(refreshData), for: .valueChanged)
    }
    
    // MARK: - Empty-state overlay
    
    private func setupEmptyStateOverlay() {
        // Create and configure a vertical stack view
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 12
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        // Icon: using a large system symbol
        let imageView = UIImageView()
        imageView.image = UIImage(systemName: "star.slash.fill")
        imageView.contentMode = .scaleAspectFit
        imageView.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 60, weight: .light)
        imageView.tintColor = UIColor(white: 1.0, alpha: 0.8)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        // Title label
        let titleLabel = UILabel()
        titleLabel.text = "No Favorite Singers"
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        titleLabel.textColor = UIColor(white: 0.2, alpha: 0.9)
        titleLabel.textAlignment = .center
        
        // Subtitle label
        let subtitleLabel = UILabel()
        subtitleLabel.text = "Your favorite singers will appear here"
        subtitleLabel.font = UIFont.systemFont(ofSize: 15)
        subtitleLabel.textColor = UIColor(white: 0.3, alpha: 0.8)
        subtitleLabel.textAlignment = .center
        
        // Add items to the stack view
        stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(subtitleLabel)
        
        // Add the stack view to the tableView
        tableView.addSubview(stackView)
        
        // Position constraints
        NSLayoutConstraint.activate([
            // Icon size
            imageView.widthAnchor.constraint(equalToConstant: 80),
            imageView.heightAnchor.constraint(equalToConstant: 80),
            
            // Stack view constraints
            stackView.centerXAnchor.constraint(equalTo: tableView.centerXAnchor),
            // Position the stack view around one-third from the top
            stackView.topAnchor.constraint(equalTo: tableView.safeAreaLayoutGuide.topAnchor, constant: tableView.bounds.height * 0.28),
            stackView.leadingAnchor.constraint(greaterThanOrEqualTo: tableView.leadingAnchor, constant: 30),
            stackView.trailingAnchor.constraint(lessThanOrEqualTo: tableView.trailingAnchor, constant: -30)
        ])
        
        // Extra spacing between the icon and the title
        stackView.setCustomSpacing(10, after: imageView)
        
        stackView.isHidden = true
        emptyStateStackView = stackView
    }
    
    private func updateEmptyStateVisibility() {
        emptyStateStackView?.isHidden = !favorites.isEmpty
    }
    
    @objc private func refreshData() {
        // Slight animation for a smoother UI
        UIView.animate(withDuration: 0.3, animations: {
            self.tableView.alpha = 0.6
        }) { _ in
            self.fetchFavoritesFromCoreData()
            UIView.animate(withDuration: 0.3) {
                self.tableView.alpha = 1.0
            }
        }
        
        // End refresh with a delay for better visibility
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            self.refreshControl?.endRefreshing()
        }
    }
    
    // MARK: - Fetch Data
    
    private func fetchFavoritesFromCoreData() {
        favorites = coreDataManager.fetchAllFavorites()
        tableView.reloadData()
        updateEmptyStateVisibility()
    }
    
    @objc private func clearAllFavorites() {
        let alert = UIAlertController(
            title: "Clear Favorites",
            message: "Are you sure you want to remove all favorite singers?",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Clear", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            
            UIView.animate(withDuration: 0.3) {
                self.tableView.alpha = 0.5
            } completion: { _ in
                self.coreDataManager.clearAllFavorites()
                self.favorites.removeAll()
                
                UIView.transition(with: self.tableView,
                                  duration: 0.5,
                                  options: .transitionCrossDissolve,
                                  animations: {
                    self.tableView.reloadData()
                    self.updateEmptyStateVisibility()
                }, completion: { _ in
                    UIView.animate(withDuration: 0.3) {
                        self.tableView.alpha = 1.0
                    }
                })
            }
        })
        
        present(alert, animated: true)
    }
    
    // MARK: - TableView DataSource
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return favorites.count
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(
            withIdentifier: "FavoriteCell",
            for: indexPath
        )
        
        configureCell(cell)
        
        let favorite = favorites[indexPath.row]
        cell.textLabel?.text = favorite.name
        cell.detailTextLabel?.text = favorite.phone
        
        // Load image
        if let imageName = favorite.image, !imageName.isEmpty {
            cell.imageView?.image = loadImage(named: imageName) ?? UIImage(named: "default")
        } else {
            cell.imageView?.image = UIImage(named: "default")
        }
        
        return cell
    }
    
    // Load image from resource bundle or document directory
    private func loadImage(named imageName: String) -> UIImage? {
        // Try loading from app bundle
        if let image = UIImage(named: imageName) {
            return image
        }
        
        // Then try loading from the Documents directory
        let documentsDirectory = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        ).first!
        let fileURL = documentsDirectory.appendingPathComponent(imageName)
        return UIImage(contentsOfFile: fileURL.path)
    }
    
    // MARK: - Configure Cell (Reverting to the green style)
    
    func configureCell(_ cell: UITableViewCell) {
        // Make cell.contentView transparent
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear
        
        // Add a gradient layer
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 160/255, blue: 180/255, alpha: 1.0).cgColor,
            UIColor(red: 160/255, green: 250/255, blue: 210/255, alpha: 1.0).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = cell.contentView.bounds
        
        // Remove any old gradient layer
        if let oldLayer = cell.contentView.layer.sublayers?.first(where: { $0 is CAGradientLayer }) {
            oldLayer.removeFromSuperlayer()
        }
        cell.contentView.layer.insertSublayer(gradientLayer, at: 0)
        
        // Green color style (same as PeopleTableViewController)
        cell.textLabel?.textColor = UIColor(red: 100/255, green: 180/255, blue: 150/255, alpha: 1.0)
        cell.textLabel?.font = UIFont.italicSystemFont(ofSize: 20)
        
        cell.detailTextLabel?.textColor = UIColor(red: 80/255, green: 150/255, blue: 130/255, alpha: 1.0)
        cell.detailTextLabel?.font = UIFont.italicSystemFont(ofSize: 14)
        
        // Make the cell image cornered
        cell.imageView?.layer.cornerRadius = 15
        cell.imageView?.layer.masksToBounds = true
        cell.imageView?.layer.borderWidth = 2
        cell.imageView?.layer.borderColor = UIColor(white: 1.0, alpha: 0.6).cgColor
        
        // Add shadow and corner radius
        cell.layer.cornerRadius = 18
        cell.layer.masksToBounds = false
        cell.layer.shadowColor = UIColor.black.cgColor
        cell.layer.shadowOpacity = 0.08
        cell.layer.shadowOffset = CGSize(width: 4, height: 4)
        cell.layer.shadowRadius = 6
    }
    
    // MARK: - TableView Delegate
    
    // Same deletion logic as PeopleTableViewController
    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCell.EditingStyle,
                            forRowAt indexPath: IndexPath
    ) {
        if editingStyle == .delete {
            let favorite = favorites[indexPath.row]
            if let singerID = favorite.singerID {
                coreDataManager.removeSingerFromFavorites(singerID: singerID)
            }
            favorites.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            updateEmptyStateVisibility()
        }
    }
    
    // Cell entrance animation
    override func tableView(_ tableView: UITableView,
                            willDisplay cell: UITableViewCell,
                            forRowAt indexPath: IndexPath
    ) {
        // Make sure the gradient covers the full cell
        if let gradientLayer = cell.contentView.layer.sublayers?.first(where: { $0 is CAGradientLayer }) as? CAGradientLayer {
            gradientLayer.frame = cell.contentView.bounds
        }
        
        // Fade in from below
        cell.alpha = 0
        cell.transform = CGAffineTransform(translationX: 0, y: 20)
        
        UIView.animate(
            withDuration: 0.3,
            delay: 0.05 * Double(indexPath.row),
            options: [.curveEaseInOut],
            animations: {
                cell.alpha = 1
                cell.transform = .identity
            }
        )
    }
    
    // Keep immediate deselect behavior
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath
    ) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let favorite = favorites[indexPath.row]
        
        // Check if the singer still exists
        if let singerID = favorite.singerID {
            if let singer = coreDataManager.getSingerByID(singerID: singerID) {
                // Additional logic, or segue to PersonViewController if needed
            } else {
                let alert = UIAlertController(
                    title: "Data Error",
                    message: "Unable to find the corresponding singer. It may have been deleted.",
                    preferredStyle: .alert
                )
                alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
                    guard let self = self else { return }
                    if let singerID = favorite.singerID {
                        self.coreDataManager.removeSingerFromFavorites(singerID: singerID)
                        self.fetchFavoritesFromCoreData()
                    }
                })
                present(alert, animated: true)
            }
        }
    }
    
    // If you need to segue to PersonViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowFavoriteSinger" {
            if let cell = sender as? UITableViewCell,
               let indexPath = tableView.indexPath(for: cell),
               let personVC = segue.destination as? PersonViewController {
                
                let favorite = favorites[indexPath.row]
                
                if let singerID = favorite.singerID,
                   let singer = coreDataManager.getSingerByID(singerID: singerID) {
                    personVC.singer = singer
                }
            }
        }
    }
}
