import UIKit
import CoreData

class DetailsViewController: UIViewController {
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var titleView: UILabel!
    @IBOutlet weak var webInfoButton: UIButton!
    
    @IBAction func webInfoAction(_ sender: Any) {
    }
    
    var personData: Person?
    var singer: Singer?  // Add this new property for CoreData
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        updateDisplayData()
    }
    
    private func updateDisplayData() {
        // Try to use CoreData Singer if available, fall back to personData if not
        if let singer = singer {
            textView.text = singer.bioText
        } else if let person = personData {
            textView.text = person.text
        } else {
            print("No data available")
        }
    }

    func setupUI() {
        addGradientBackground()
        
        titleView.backgroundColor = UIColor(red: 255/255, green: 230/255, blue: 240/255, alpha: 0.9)
        titleView.layer.cornerRadius = 20
        titleView.layer.masksToBounds = true
        titleView.textAlignment = .center
        titleView.font = UIFont.italicSystemFont(ofSize: 24)
        titleView.textColor = UIColor(red: 50/255, green: 120/255, blue: 100/255, alpha: 1.0)

        textView.backgroundColor = UIColor(white: 1.0, alpha: 0.6)
        textView.layer.cornerRadius = 20
        textView.layer.masksToBounds = true
        textView.font = UIFont.italicSystemFont(ofSize: 18)
        textView.textColor = UIColor(red: 60/255, green: 140/255, blue: 110/255, alpha: 1.0)
        textView.layer.borderWidth = 1
        textView.layer.borderColor = UIColor(white: 1.0, alpha: 0.7).cgColor
        textView.layer.shadowColor = UIColor.black.cgColor
        textView.layer.shadowOpacity = 0.1
        textView.layer.shadowOffset = CGSize(width: 3, height: 3)
        textView.layer.shadowRadius = 6

        webInfoButton.setTitleColor(UIColor.white, for: .normal)
        webInfoButton.titleLabel?.font = UIFont.italicSystemFont(ofSize: 20)
        webInfoButton.layer.cornerRadius = 20
        webInfoButton.layer.masksToBounds = false

        let buttonGradient = CAGradientLayer()
        buttonGradient.colors = [
            UIColor(red: 255/255, green: 90/255, blue: 140/255, alpha: 1.0).cgColor,
            UIColor(red: 255/255, green: 140/255, blue: 180/255, alpha: 1.0).cgColor
        ]
        buttonGradient.startPoint = CGPoint(x: 0, y: 0)
        buttonGradient.endPoint = CGPoint(x: 1, y: 1)
        buttonGradient.frame = webInfoButton.bounds
        buttonGradient.cornerRadius = 20
        webInfoButton.layer.insertSublayer(buttonGradient, at: 0)

        webInfoButton.layer.shadowColor = UIColor.black.cgColor
        webInfoButton.layer.shadowOpacity = 0.2
        webInfoButton.layer.shadowOffset = CGSize(width: 3, height: 3)
        webInfoButton.layer.shadowRadius = 8

        webInfoButton.addTarget(self, action: #selector(buttonPressed), for: .touchDown)
        webInfoButton.addTarget(self, action: #selector(buttonReleased), for: [.touchUpInside, .touchDragExit])
    }

    func addGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 200/255, blue: 220/255, alpha: 1.0).cgColor,
            UIColor(red: 140/255, green: 220/255, blue: 190/255, alpha: 1.0).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds

        if view.layer.sublayers?.contains(where: { $0 is CAGradientLayer }) == false {
            view.layer.insertSublayer(gradientLayer, at: 0)
        }
    }

    @objc func buttonPressed() {
        webInfoButton.alpha = 0.75
    }

    @objc func buttonReleased() {
        webInfoButton.alpha = 1.0
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Segue0" {
            if let destination = segue.destination as? WebViewController {
                // Pass both models for compatibility
                destination.personData = self.personData
                destination.singer = self.singer  // Pass the CoreData object
                
                // Set the URL based on whichever data is available
                if let singer = singer, let websiteUrl = singer.websiteUrl {
                    destination.urlData = websiteUrl
                } else if let personData = personData {
                    destination.urlData = personData.url
                }
            }
        }
    }
}
