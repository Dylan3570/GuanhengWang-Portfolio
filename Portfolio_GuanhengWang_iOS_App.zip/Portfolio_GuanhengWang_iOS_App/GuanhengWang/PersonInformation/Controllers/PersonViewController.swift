import UIKit
import CoreData

class PersonViewController: UIViewController {

    // MARK: - Properties
    
    var personData: Person?
    var singer: Singer?
    let coreDataManager = CoreDataManager.shared
    
    // UI Components
    @IBOutlet weak var personImageView: UIImageView!
    @IBOutlet weak var personNameLabel: UILabel!
    @IBOutlet weak var personAddressLabel: UILabel!
    @IBOutlet weak var personPhoneLabel: UILabel!
    
    @IBOutlet weak var moreInfoview: UIButton!
    
    @IBOutlet weak var titleView: UILabel!
    @IBOutlet weak var nameview: UILabel!
    @IBOutlet weak var addressView: UILabel!
    @IBOutlet weak var phoneView: UILabel!
    
    // Record the current favorite state
    private var isFavorite: Bool = false
    // Reference for the custom star button
    private var starButton: UIButton?

    // Vivid golden color
    private let strongGoldColor = UIColor(
        red: 1.0,
        green: 0.85,
        blue: 0.0,
        alpha: 1.0
    )
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        // No longer hide the view to avoid a black screen flicker
        // view.isHidden = true
        
        // Set up the star button on the right side of the navigation bar
        setupFavoriteBarButtonItem()
        
        // Update data immediately
        updateDisplayData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Update display information
        updateDisplayData()
        updateFavoriteBarButtonIcon()
        
        // Use smoother transition effects
        if view.alpha < 1.0 {
            view.alpha = 0.95
            UIView.animate(withDuration: 0.2) {
                self.view.alpha = 1.0
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue1",
           let destination = segue.destination as? DetailsViewController {
            destination.personData = self.personData
            destination.singer = self.singer
        }
    }
    
    // MARK: - UI Setup
    
    func setupUI() {
        addGradientBackground()
        radius()
        applyLabelStyles()
        bringLabelsToFront()
        
        moreInfoview.setTitleColor(UIColor.white, for: .normal)
        moreInfoview.titleLabel?.font = UIFont.italicSystemFont(ofSize: 20)
        moreInfoview.layer.cornerRadius = 20
        
        updateButtonGradient()
    }
    
    // Load image from the documents directory or asset catalog
    private func loadImage(named imageName: String) -> UIImage? {
        // First, attempt to load from the app bundle
        if let image = UIImage(named: imageName) {
            return image
        }
        
        // Then, try to load from the documents directory
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documentsDirectory.appendingPathComponent(imageName)
        
        // Debug log to confirm file path
        print("Attempting to load image from file: \(fileURL.path)")
        
        // Check if the file exists
        if FileManager.default.fileExists(atPath: fileURL.path) {
            if let image = UIImage(contentsOfFile: fileURL.path) {
                print("Successfully loaded image from file")
                return image
            } else {
                print("File exists but failed to load as image")
            }
        } else {
            print("File does not exist at path: \(fileURL.path)")
        }
        
        return nil
    }
    
    /// Update display data, updating the UI only if singer or personData is not nil
    private func updateDisplayData() {
        if let singer = singer {
            if let imageName = singer.image, !imageName.isEmpty {
                // Use the new image loading method
                personImageView.image = loadImage(named: imageName) ?? UIImage(named: "default")
            } else {
                personImageView.image = UIImage(named: "default")
            }
            personNameLabel.text = singer.name
            personAddressLabel.text = singer.address
            personPhoneLabel.text = singer.phone
            
        } else if let person = personData {
            // Fix error here by directly checking if the string is empty
            if !person.image.isEmpty {
                personImageView.image = loadImage(named: person.image) ?? UIImage(named: "default")
            } else {
                personImageView.image = UIImage(named: "default")
            }
            personNameLabel.text = person.name
            personAddressLabel.text = person.address
            personPhoneLabel.text = person.phone
        }
        // If both are nil, the UI is not updated and no "no data" placeholder is shown.
    }
    
    // MARK: - Navigation Bar Star Button
    
    private func setupFavoriteBarButtonItem() {
        guard let singer = singer, let singerID = singer.name else {
            navigationItem.rightBarButtonItem = nil
            return
        }
        
        isFavorite = coreDataManager.isSingerInFavorites(singerID: singerID)
        
        let button = UIButton(type: .system)
        let starImageName = isFavorite ? "star.fill" : "star"
        button.setImage(UIImage(systemName: starImageName), for: .normal)
        button.tintColor = strongGoldColor
        button.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        setupStarButtonAppearance(button)
        button.addTarget(self, action: #selector(didTapFavoriteBarButton), for: .touchUpInside)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: button)
        self.starButton = button
    }
    
    private func updateFavoriteBarButtonIcon() {
        guard let singer = singer, let singerID = singer.name else {
            navigationItem.rightBarButtonItem = nil
            return
        }
        isFavorite = coreDataManager.isSingerInFavorites(singerID: singerID)
        
        let starImageName = isFavorite ? "star.fill" : "star"
        starButton?.setImage(UIImage(systemName: starImageName), for: .normal)
        if let btn = starButton {
            setupStarButtonAppearance(btn)
        }
    }
    
    @objc private func didTapFavoriteBarButton() {
        guard let singer = singer, let singerID = singer.name else {
            return
        }
        
        isFavorite.toggle()
        let starImageName = isFavorite ? "star.fill" : "star"
        starButton?.setImage(UIImage(systemName: starImageName), for: .normal)
        if let btn = starButton {
            setupStarButtonAppearance(btn)
        }
        
        if isFavorite {
            coreDataManager.addSingerToFavorites(
                name: singer.name ?? "",
                singerID: singerID,
                address: singer.address ?? "",
                phone: singer.phone ?? "",
                image: singer.image ?? ""
            )
        } else {
            coreDataManager.removeSingerFromFavorites(singerID: singerID)
        }
    }
    
    // Keep the original appearance settings for the button unchanged
    private func setupStarButtonAppearance(_ button: UIButton) {
        button.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        button.tintColor = strongGoldColor
        button.layer.cornerRadius = button.frame.height / 2
        button.layer.masksToBounds = false
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.white.withAlphaComponent(0.7).cgColor
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 2)
        button.layer.shadowOpacity = 0.3
        button.layer.shadowRadius = 2
    }
    
    // MARK: - Layout / Styles
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        makeImageViewSquare()
        updateButtonGradient()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        makeImageViewSquare()
        applyLabelStyles()
    }

    private func makeImageViewSquare() {
        personImageView.layoutIfNeeded()
        let sideLength = min(personImageView.frame.width, personImageView.frame.height)
        personImageView.frame.size = CGSize(width: sideLength, height: sideLength)
        personImageView.layer.cornerRadius = sideLength / 2
        personImageView.layer.masksToBounds = true
        personImageView.clipsToBounds = true
        personImageView.layer.borderWidth = 4
        personImageView.layer.borderColor = UIColor.white.cgColor
    }

    func radius() {
        let viewsToRound: [UIView] = [
            phoneView, nameview, addressView,
            personPhoneLabel, personNameLabel, personAddressLabel,
            titleView
        ]
        for view in viewsToRound {
            view.layer.cornerRadius = 20
            view.layer.masksToBounds = true
            view.backgroundColor = UIColor(white: 1.0, alpha: 0.6)
            view.layer.borderWidth = 1
            view.layer.borderColor = UIColor(white: 1.0, alpha: 0.7).cgColor
            view.layer.shadowColor = UIColor.black.cgColor
            view.layer.shadowOpacity = 0.1
            view.layer.shadowOffset = CGSize(width: 3, height: 3)
            view.layer.shadowRadius = 6
        }
    }

    func addGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 200/255, blue: 220/255, alpha: 1.0).cgColor,
            UIColor(red: 140/255, green: 220/255, blue: 190/255, alpha: 1.0).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds

        if view.layer.sublayers?.contains(where: { $0 is CAGradientLayer }) == false {
            view.layer.insertSublayer(gradientLayer, at: 0)
        }
    }

    func updateButtonGradient() {
        if let oldLayer = moreInfoview.layer.sublayers?.first(where: { $0 is CAGradientLayer }) {
            oldLayer.removeFromSuperlayer()
        }
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 90/255, blue: 140/255, alpha: 1.0).cgColor,
            UIColor(red: 255/255, green: 140/255, blue: 180/255, alpha: 1.0).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = moreInfoview.bounds
        gradientLayer.cornerRadius = 20
        moreInfoview.layer.insertSublayer(gradientLayer, at: 0)
    }

    func applyLabelStyles() {
        let allTextViews: [UILabel] = [
            titleView, nameview, addressView, phoneView,
            personNameLabel, personAddressLabel, personPhoneLabel
        ]
        for label in allTextViews {
            label.textAlignment = .center
            label.font = UIFont.italicSystemFont(ofSize: 22)
            label.textColor = UIColor(red: 50/255, green: 120/255, blue: 100/255, alpha: 1.0)
        }
    }

    func bringLabelsToFront() {
        let allTextViews: [UILabel] = [
            titleView, nameview, addressView, phoneView,
            personNameLabel, personAddressLabel, personPhoneLabel
        ]
        for label in allTextViews {
            view.bringSubviewToFront(label)
        }
        view.bringSubviewToFront(moreInfoview)
    }
}
