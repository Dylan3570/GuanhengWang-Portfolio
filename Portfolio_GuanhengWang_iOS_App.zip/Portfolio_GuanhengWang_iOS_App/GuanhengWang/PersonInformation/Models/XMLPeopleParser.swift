import Foundation

class XMLPeopleParser: NSObject, XMLParserDelegate{
   
    // property + init
    var name : String
    init(name:String){self.name = name}
    
    // vars to get the data from xml tags
    var pName, pAddress, pPhone, pImage, pText, pUrl : String!
    
    let tages = ["name", "address", "phone", "image", "url", "text"]
    
    // var to spy on data
    var elementId = -1
    var passData = false
    
    // vars to manage the date from xml
    var peopleData = [Person]()
    var personData : Person!
    
    //parser
    var parser = XMLParser()
    
    //override the delegate methods
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        // check passDate and elementID
        if passData{
            switch elementId {
                case 0: pName = string
                case 1: pAddress = string
                case 2: pPhone = string
                case 3: pImage = string
                case 4: pUrl = string
                case 5: pText = string
                
            default: break
            }
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        // check the tags and block the spies
        if tages.contains(elementName){
            passData = false
            elementId = -1
        }
        
        // check end tag person
        if elementName == "person"{
            // make a personData
            personData = Person(
                name: pName ?? "",
                address: pAddress ?? "",
                phone: pPhone ?? "",
                image: pImage ?? "",
                url: pUrl ?? "",
                text: pText ?? ""
            )
            
            // append personData to peopleData
            peopleData.append(personData)
        }
        
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        // check if elementName is in tages
        if tages.contains(elementName){
            passData = true
            switch elementName {
                case "name"   : elementId = 0
                case "address": elementId = 1
                case "phone"  : elementId = 2
                case "image"  : elementId = 3
                case "url"    : elementId = 4
                case "text" : elementId = 5
                
                default: break
                
            }
        }
    }
    
    //start parsing
    func parsing(){
        // get the path to xml file
        let bundleUrl = Bundle.main.bundleURL
        let fileUrl = URL(fileURLWithPath: self.name, relativeTo: bundleUrl)
        
        parser = XMLParser(contentsOf: fileUrl)!
        parser.delegate = self
        
        parser.parse()
        
    }
    
}
