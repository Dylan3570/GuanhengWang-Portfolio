from turtle import *

#Binary Tree
def tree(n, l, pen):
    if n == 0 or l < 2:
        return
    pen.forward(l)
    pen.left(45)
    tree(n - 1, l / 2, pen)
    pen.right(90)
    tree(n - 1, l / 2, pen)
    pen.left(45)
    pen.backward(l)


#Quad Tree
def dandelion(n, l, pen):
    if n == 0 or l < 2:
        return
    pen.forward(l)
    pen.left(90)
    dandelion(n - 1, l / 2, pen)
    pen.right(60)
    dandelion(n - 1, l / 2, pen)
    pen.right(60)
    dandelion(n - 1, l / 2, pen)
    pen.right(60)
    dandelion(n - 1, l / 2, pen)
    pen.left(90)
    pen.backward(l)

    
# Fern
def fern(n, l, pen):
    if n == 0 or l < 2:
        return
    pen.forward(2 * l / 3)
    pen.right(45)
    fern(n - 1, 0.5 * l, pen)
    pen.left(45)
    pen.forward(2 * l / 3)
    pen.left(30)
    fern(n - 1, 0.6 * l, pen)
    pen.right(30)
    pen.forward(2 * l / 3)
    pen.right(10)
    fern(n - 1, 0.8 * l, pen)
    pen.left(10)
    pen.backward(2 * l)

    
# Snowflake and Anti-snowflake
def koch(n, l, pen):
    if n == 0 or l < 2:
        pen.forward(l)
        return
    koch(n - 1, l / 3, pen)
    pen.left(60)
    koch(n - 1, l / 3, pen)
    pen.right(120)
    koch(n - 1, l / 3, pen)
    pen.left(60)
    koch(n - 1, l / 3, pen)

def flake(n, l, pen):
    for _ in range(3):
        koch(n, l, pen)
        pen.right(120)

def antiflake(n, l, pen):
    for _ in range(3):
        koch(n, l, pen)
        pen.left(120)

# S-Gasket
def s_gasket(n, l, pen):
    if n == 0 or l < 2:
        for _ in range(3):
            pen.forward(l)
            pen.left(120)
        return
    s_gasket(n - 1, l / 2, pen)
    pen.forward(l / 2)
    s_gasket(n - 1, l / 2, pen)
    pen.backward(l / 2)
    pen.left(60)
    pen.forward(l / 2)
    pen.right(60)
    s_gasket(n - 1, l / 2, pen)
    pen.left(60)
    pen.backward(l / 2)
    pen.right(60)
   
#Balloon
def ballon(n, length, pen):
    if n == 0:
        return
    for _ in range(4):
        pen.circle(length)
        pen.penup()
        pen.forward(length * 2)
        pen.pendown()
        ballon(n - 1, length * 0.5, pen)
        pen.penup()
        pen.backward(length * 2)
        pen.right(90)
        pen.pendown()

#Chrysanthemum
def chrysanthemum(n, length, pen):
    if n == 0:
        return
    for _ in range(8):
        pen.circle(length)
        pen.left(45)
        chrysanthemum(n - 1, length * 0.6, pen)

#Windmill
def windmill(n, length, pen):
    if n == 0:
        return
    for _ in range(4):
        for _ in range(2):
            pen.forward(length)
            pen.right(60)
            pen.forward(length)
            pen.right(120)
        pen.forward(length)
        windmill(n - 1, length * 0.5, pen)
        pen.backward(length)
        pen.right(90)

#Circular
def circular(n, length, pen):
    if n == 0:
        pen.circle(length)
        return
    for _ in range(6):
        circular(n - 1, length * 0.75, pen)
        pen.right(60 + n * 15)
