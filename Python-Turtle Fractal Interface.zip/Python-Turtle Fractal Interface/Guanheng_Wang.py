from tkinter import *
from turtle import *
import turtlefigure 

root = Tk()
root.title("Fractal Interface")
root.geometry("1000x800")

mainFrame = Frame(root, padx=10, pady=10)
mainFrame.pack(fill=BOTH, expand=True)

combinedFrame = Frame(mainFrame)
combinedFrame.pack(fill=BOTH, expand=True)

canvasFrame = Frame(combinedFrame, bd=2, relief=RIDGE)
canvasFrame.pack(side=LEFT, padx=(5, 5), pady=(20, 10))

canvasTitle = Label(canvasFrame, text="Turtle Canvas", font=("Arial", 14, "bold"))
canvasTitle.pack(pady=(5, 0))

turtleCanvas = Canvas(canvasFrame, width=650, height=700)
turtleCanvas.pack()

screen = TurtleScreen(turtleCanvas)
screen.bgcolor("lightblue")
pen = RawTurtle(screen)
pen.speed(0)
pen.color("mediumseagreen")

color_options = ["lightblue", "lavender", "lightcoral", "peachpuff", "lightpink", "palegreen", "skyblue", "plum", "mistyrose", "wheat"]

def clearF():
    pen.clear()

def drawF():
    fractal_type = fractalVar.get()
    order = int(orderVar.get())
    length = int(LengthVar.get())
    pen.shape(shapeVar.get())
    pen.width(widthSlider.get())
    pen.up()
    pen.goto(0, 0)
    pen.down()
    if fractal_type == "Binary Tree":
        turtlefigure.tree(order, length, pen)
        update_description("Generates a branching binary tree structure, where each node splits into two child nodes, forming a tree-like shape.")
    elif fractal_type == "Quad Tree":
        turtlefigure.dandelion(order, length, pen)
        update_description("Similar to binary trees, but each node splits into four child nodes, creating a more complex tree structure.")
    elif fractal_type == "Fern":
        turtlefigure.fern(order, length, pen)
        update_description("Creates a natural fern shape through recursion, featuring intricate leaf structures.")
    elif fractal_type == "Snowflake":
        turtlefigure.flake(order, length, pen)
        update_description("Produces a beautiful snowflake pattern through continuous fractal iterations, resulting in unique designs.")
    elif fractal_type == "Anti-snowflake":
        turtlefigure.antiflake(order, length, pen)
        update_description("Similar to a snowflake, but employs different fractal methods at each branch, creating a symmetrical effect.")
    elif fractal_type == "S-Gasket":
        turtlefigure.s_gasket(order, length, pen)
        update_description("Generates an S-shaped triangle fractal, adding new smaller triangles inside the larger triangle at each recursion.")
    elif fractal_type == "Balloon":
        turtlefigure.ballon(order, length, pen)
        update_description("Creates multiple balloon shapes that expand upward through recursion, forming rich patterns.")
    elif fractal_type == "Chrysanthemum":
        turtlefigure.chrysanthemum(order, length, pen)
        update_description("Produces a chrysanthemum-like fractal by layering multiple circles to create vibrant petals.")
    elif fractal_type == "Windmill":
        turtlefigure.windmill(order, length, pen)
        update_description("Creates a windmill shape, generating dynamic visuals through multiple rotations and repetitions.")
    elif fractal_type == "Circular":
        turtlefigure.circular(order, length, pen)
        update_description("Generates multiple ring patterns, each created recursively, forming beautiful spiral effects.")

def update_description(description):
    description_text.delete(1.0, END)
    description_text.insert(END, description)

def update_pen_color(*args):
    pen.color(penColorVar.get())

def update_bg_color(*args):
    screen.bgcolor(bgColorVar.get())

controlFrame = Frame(combinedFrame, bd=2, relief=RIDGE)
controlFrame.pack(side=RIGHT, fill=Y, padx=5, pady=(20, 10))

controlTitle = Label(controlFrame, text="Control Panel", font=("Arial", 14, "bold"))
controlTitle.pack(pady=(5, 0))

buttonFrame = Frame(controlFrame)
buttonFrame.pack(pady=5)

clearButton = Button(buttonFrame, text="Clear", command=clearF)
clearButton.pack(side=LEFT, padx=5)
drawButton = Button(buttonFrame, text="Draw", command=drawF)
drawButton.pack(side=LEFT, padx=5)

inputFrame = Frame(controlFrame, bd=2, relief=RIDGE)
inputFrame.pack(pady=10, fill=X)

inputTitle = Label(inputFrame, text="Input Panel", font=("Arial", 14, "bold"))
inputTitle.grid(row=0, columnspan=2, pady=(5, 10))

orderLabel = Label(inputFrame, text="Order:")
orderLabel.grid(row=1, column=0, sticky=W, pady=5)
orderVar = StringVar()
orderEntry = Entry(inputFrame, textvariable=orderVar, width=12)
orderEntry.grid(row=1, column=1, pady=5)

LengthLabel = Label(inputFrame, text="Length:")
LengthLabel.grid(row=2, column=0, sticky=W, pady=5)
LengthVar = StringVar()
LengthEntry = Entry(inputFrame, textvariable=LengthVar, width=12)
LengthEntry.grid(row=2, column=1, pady=5)

fractalLabel = Label(inputFrame, text="Fractal:")
fractalLabel.grid(row=3, column=0, sticky=W, pady=5)
fractalVar = StringVar()
fractalOptionMenu = OptionMenu(inputFrame, 
                                fractalVar, 
                                "Binary Tree", 
                                "Quad Tree", 
                                "Fern", 
                                "Snowflake", 
                                "Anti-snowflake", 
                                "S-Gasket",
                                "Balloon",
                                "Chrysanthemum",
                                "Windmill",
                                "Circular")
fractalOptionMenu.grid(row=3, column=1, pady=5)
fractalVar.set("Binary Tree")

shapeLabel = Label(inputFrame, text="Turtle Shape:")
shapeLabel.grid(row=4, column=0, sticky=W, pady=5)
shapeVar = StringVar()
shapeOptionMenu = OptionMenu(inputFrame, shapeVar, "classic", "turtle", "arrow", "circle", "square", "triangle")
shapeOptionMenu.grid(row=4, column=1, pady=5)
shapeVar.set("classic")

widthLabel = Label(inputFrame, text="Pen Width:")
widthLabel.grid(row=5, column=0, sticky=W, pady=5)
widthSlider = Scale(inputFrame, from_=1, to=10, orient=HORIZONTAL)
widthSlider.grid(row=5, column=1, pady=5)
widthSlider.set(1)

penColorLabel = Label(inputFrame, text="Pen Color:")
penColorLabel.grid(row=6, column=0, sticky=W, pady=5)
penColorVar = StringVar(value="green")
penColorOptionMenu = OptionMenu(inputFrame, penColorVar, *color_options)
penColorOptionMenu.grid(row=6, column=1, pady=5)
penColorVar.trace("w", update_pen_color)

bgColorLabel = Label(inputFrame, text="Background Color:")
bgColorLabel.grid(row=7, column=0, sticky=W, pady=5)
bgColorVar = StringVar(value="lightblue")
bgColorOptionMenu = OptionMenu(inputFrame, bgColorVar, *color_options)
bgColorOptionMenu.grid(row=7, column=1, pady=5)
bgColorVar.trace("w", update_bg_color)

description_label = Label(controlFrame, text="Figure Information:", font=("Arial", 14, "bold"))
description_label.pack(pady=5)
description_text = Text(controlFrame, height=5, width=40, wrap=WORD, font=("Arial", 12))
description_text.pack(pady=5)

root.mainloop()
