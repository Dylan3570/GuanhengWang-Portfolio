Personal Figures and ContributionsOverview

This project is a graphical application that I developed using Python's tkinter and turtle libraries, designed to create various fractal patterns. By adjusting parameters such as order, length, fractal type, pen shape, and colors, I can generate intricate and beautiful designs.

Personal Figures

In my application, I have implemented the following personal fractal figures, each with its unique characteristics and drawing methods:

Balloon: Produces multiple balloon shapes that expand upward recursively, forming rich patterns.
Chrysanthemum: Creates a flower-like fractal by layering multiple circles to produce vibrant petals.
Windmill: Draws a windmill shape with dynamic visuals through multiple rotations.
Circular: Generates multiple ring patterns recursively, forming beautiful spiral effects.
Personal Contributions

My key contributions to this project include:

Design and Implementation: I developed the graphical user interface using tkinter, allowing users to interactively choose fractal types and customize parameters.
Fractal Algorithms: I implemented unique algorithms for each fractal type in the turtlefigure module, showcasing various recursive drawing techniques.
User Experience: I focused on usability by providing clear labels, input fields, and a description area to inform users about the generated figures.
Color Customization: I included features for changing pen and background colors to enhance visual appeal.
Usage

To use the application, run the main script, and the graphical interface will appear. Select a fractal type, set the order and length, choose a pen shape, and click "Draw" to create the fractal. Use the "Clear" button to reset the canvas.

Conclusion

This project serves as a fun and educational tool for me to explore fractals and their fascinating properties. The interface encourages creativity while allowing users to visualize complex mathematical concepts in an engaging manner.