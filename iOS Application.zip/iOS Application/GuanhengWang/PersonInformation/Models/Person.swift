import Foundation

class Person{
    
    // class properties
    var name, address, phone, image, url, text : String
    
    // class init-s
    init(name: String, address: String, phone: String, image: String, url: String, text: String) {
        self.name = name
        self.address = address
        self.phone = phone
        self.image = image
        self.url = url
        self.text = text
    
    }
    init() {
        self.name = "John Doe"
        self.address = "no address"
        self.phone = "no phone"
        self.image = "doe.jpg"
        self.url = ""
        self.text = ""
    }
    
    // class methods
    
}
