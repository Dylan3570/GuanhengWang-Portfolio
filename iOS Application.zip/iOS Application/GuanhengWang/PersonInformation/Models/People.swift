import Foundation
class People{
    
    var peopleData : [Person]
    
    init(){
        
        self.peopleData =
        [
            Person(name: "Sabin Tabirca", address: "WGB, UCC, Cork", phone: "12345678", image: "sabin.jpeg", url: "http://www.cs.ucc.ie", text: "aaa"),
            Person(name: "Sabina Tabirca", address: "CUMH, UCC, Cork", phone: "12345678", image: "sabin.jpeg", url: "http://www.cs.ucc.ie", text: "aaa"),
            Person(name: "John Tabirca", address: "Loyds,  Cork", phone: "12345678", image: "sabin.jpeg", url: "http://www.cs.ucc.ie", text: "aaa"),
            Person(name: "Tany Tabirca", address: "WGB, UCC, Cork", phone: "12345678", image: "sabin.jpeg", url: "http://www.cs.ucc.ie", text: "aaa"),
            Person(name: "Sabinus Tabirca", address: "WGB, UCC, Cork", phone: "12345678", image: "sabin.jpeg", url: "http://www.cs.ucc.ie", text: "aaa")
        ]
    }
    
    init(fromXMLFile: String){
        let parser = XMLPeopleParser(name: fromXMLFile)
        parser.parsing()
        
        self.peopleData = parser.peopleData
    }
    
    //methods
    func getPerson(index:Int)-> Person{
        return peopleData[index]
    }
    
    func getCount()->Int{
        return peopleData.count
    }
}
