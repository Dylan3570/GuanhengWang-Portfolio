import UIKit
import CoreData

class DeletedSingersViewController: UITableViewController {

    var deletedSingers: [DeletedSinger] = []
    let coreDataManager = CoreDataManager.shared
    
    // Container for the empty-state view
    private var emptyStateStackView: UIStackView?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Deleted History"
        
        // Set up the gradient background, pull-to-refresh, etc.
        setupUI()
        
        // Set up the empty-state overlay
        setupEmptyStateOverlay()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Fetch the latest deleted records each time the view appears
        fetchDeletedSingersFromCoreData()
    }

    // MARK: - UI Setup (Gradient background + Pull to refresh)
    private func setupUI() {
        // 1) Pink → Light Green Gradient
        let backgroundGradient = CAGradientLayer()
        backgroundGradient.colors = [
            UIColor(red: 255/255, green: 160/255, blue: 180/255, alpha: 1.0).cgColor,
            UIColor(red: 160/255, green: 250/255, blue: 210/255, alpha: 1.0).cgColor
        ]
        backgroundGradient.startPoint = CGPoint(x: 0, y: 0)
        backgroundGradient.endPoint = CGPoint(x: 1, y: 1)
        backgroundGradient.frame = view.bounds
        
        let bgView = UIView(frame: view.bounds)
        bgView.layer.insertSublayer(backgroundGradient, at: 0)
        tableView.backgroundView = bgView
        
        // 2) Clear-all button on the right side of the navigation bar
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .trash,
            target: self,
            action: #selector(clearAllDeletedSingers)
        )
        navigationItem.rightBarButtonItem?.tintColor = UIColor(
            red: 255/255, green: 100/255, blue: 150/255, alpha: 1.0
        )
        
        // 3) Pull to refresh
        refreshControl = UIRefreshControl()
        refreshControl?.tintColor = UIColor(red: 255/255, green: 100/255, blue: 150/255, alpha: 1.0)
        refreshControl?.addTarget(self, action: #selector(refreshData), for: .valueChanged)
    }
    
    @objc private func refreshData() {
        UIView.animate(withDuration: 0.3) {
            self.tableView.alpha = 0.6
        } completion: { _ in
            self.fetchDeletedSingersFromCoreData()
            UIView.animate(withDuration: 0.3) {
                self.tableView.alpha = 1.0
            }
        }
        
        // End the refresh animation with a slight delay for better visual feedback
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            self.refreshControl?.endRefreshing()
        }
    }
    
    // MARK: - Empty State Overlay
    private func setupEmptyStateOverlay() {
        // Create and configure a vertical stack view
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 12
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        // Icon: using a large system symbol
        let imageView = UIImageView()
        imageView.image = UIImage(systemName: "trash.slash.fill")
        imageView.contentMode = .scaleAspectFit
        imageView.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 60, weight: .light)
        imageView.tintColor = UIColor(white: 1.0, alpha: 0.8)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        // Main label
        let titleLabel = UILabel()
        titleLabel.text = "No Deleted History"
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        titleLabel.textColor = UIColor(white: 0.2, alpha: 0.9)
        titleLabel.textAlignment = .center
        
        // Subtitle label
        let subtitleLabel = UILabel()
        subtitleLabel.text = "Deleted singers will appear here"
        subtitleLabel.font = UIFont.systemFont(ofSize: 15)
        subtitleLabel.textColor = UIColor(white: 0.3, alpha: 0.8)
        subtitleLabel.textAlignment = .center
        
        // Add views to the stack view
        stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(subtitleLabel)
        
        // Add stack view to tableView
        tableView.addSubview(stackView)
        
        // Set constraints to position the content closer to the top
        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalToConstant: 80),
            imageView.heightAnchor.constraint(equalToConstant: 80),
            
            stackView.centerXAnchor.constraint(equalTo: tableView.centerXAnchor),
            // Position the stack view at about 28% from the top
            stackView.topAnchor.constraint(equalTo: tableView.safeAreaLayoutGuide.topAnchor, constant: tableView.bounds.height * 0.28),
            stackView.leadingAnchor.constraint(greaterThanOrEqualTo: tableView.leadingAnchor, constant: 30),
            stackView.trailingAnchor.constraint(lessThanOrEqualTo: tableView.trailingAnchor, constant: -30)
        ])
        
        // Add extra spacing
        stackView.setCustomSpacing(10, after: imageView)
        
        stackView.isHidden = true
        emptyStateStackView = stackView
    }
    
    private func updateEmptyStateVisibility() {
        emptyStateStackView?.isHidden = !deletedSingers.isEmpty
    }

    // MARK: - Fetch deleted history
    private func fetchDeletedSingersFromCoreData() {
        deletedSingers = coreDataManager.fetchAllDeletedSingers()
        tableView.reloadData()
        updateEmptyStateVisibility()
    }

    // MARK: - Clear all deleted history
    @objc private func clearAllDeletedSingers() {
        let alert = UIAlertController(
            title: "Clear History",
            message: "Are you sure you want to permanently delete all history? This action cannot be undone.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Clear", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            
            UIView.animate(withDuration: 0.3) {
                self.tableView.alpha = 0.5
            } completion: { _ in
                self.coreDataManager.clearAllDeletedSingers()
                self.deletedSingers.removeAll()
                
                UIView.transition(with: self.tableView,
                                  duration: 0.5,
                                  options: .transitionCrossDissolve,
                                  animations: {
                    self.tableView.reloadData()
                    self.updateEmptyStateVisibility()
                }, completion: { _ in
                    UIView.animate(withDuration: 0.3) {
                        self.tableView.alpha = 1.0
                    }
                })
            }
        })
        
        present(alert, animated: true)
    }

    // MARK: - TableView DataSource/Delegate
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return deletedSingers.count
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(
            withIdentifier: "DeletedSingerCell",
            for: indexPath
        )
        configureCell(cell)
        
        let deletedSinger = deletedSingers[indexPath.row]
        cell.textLabel?.text = deletedSinger.name
        
        // Format the deletion date
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .short
        if let deletionDate = deletedSinger.deletionDate {
            cell.detailTextLabel?.text = "Deleted on: \(dateFormatter.string(from: deletionDate))"
        } else {
            cell.detailTextLabel?.text = "Unknown deletion time"
        }
        
        // Load the image
        if let imageName = deletedSinger.image, !imageName.isEmpty {
            cell.imageView?.image = loadImage(named: imageName) ?? UIImage(named: "default")
        } else {
            cell.imageView?.image = UIImage(named: "default")
        }
        
        return cell
    }
    
    // Load image from the resource bundle or the Documents directory
    private func loadImage(named imageName: String) -> UIImage? {
        // Try the app bundle first
        if let image = UIImage(named: imageName) {
            return image
        }
        // Then the Documents directory
        let documentsDirectory = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        ).first!
        let fileURL = documentsDirectory.appendingPathComponent(imageName)
        return UIImage(contentsOfFile: fileURL.path)
    }
    
    // Configure the cell with the original green style
    func configureCell(_ cell: UITableViewCell) {
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear
        
        // Gradient background
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 160/255, blue: 180/255, alpha: 1.0).cgColor,
            UIColor(red: 160/255, green: 250/255, blue: 210/255, alpha: 1.0).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = cell.contentView.bounds
        
        // Remove any old gradient layer
        if let oldLayer = cell.contentView.layer.sublayers?.first(where: { $0 is CAGradientLayer }) {
            oldLayer.removeFromSuperlayer()
        }
        cell.contentView.layer.insertSublayer(gradientLayer, at: 0)
        
        // Revert to the original green color style
        cell.textLabel?.textColor = UIColor(red: 100/255, green: 180/255, blue: 150/255, alpha: 1.0)
        cell.textLabel?.font = UIFont.italicSystemFont(ofSize: 20)
        
        cell.detailTextLabel?.textColor = UIColor(red: 80/255, green: 150/255, blue: 130/255, alpha: 1.0)
        cell.detailTextLabel?.font = UIFont.italicSystemFont(ofSize: 14)
        
        // Image rounded corners + border
        cell.imageView?.layer.cornerRadius = 15
        cell.imageView?.layer.masksToBounds = true
        cell.imageView?.layer.borderWidth = 2
        cell.imageView?.layer.borderColor = UIColor(white: 1.0, alpha: 0.6).cgColor
        
        // Cell shadow and corner radius
        cell.layer.cornerRadius = 18
        cell.layer.masksToBounds = false
        cell.layer.shadowColor = UIColor.black.cgColor
        cell.layer.shadowOpacity = 0.08
        cell.layer.shadowOffset = CGSize(width: 4, height: 4)
        cell.layer.shadowRadius = 6
    }
    
    // Entrance animation
    override func tableView(_ tableView: UITableView,
                            willDisplay cell: UITableViewCell,
                            forRowAt indexPath: IndexPath) {
        if let gradientLayer = cell.contentView.layer.sublayers?.first(where: { $0 is CAGradientLayer }) as? CAGradientLayer {
            gradientLayer.frame = cell.contentView.bounds
        }
        
        cell.alpha = 0
        cell.transform = CGAffineTransform(translationX: 0, y: 20)
        UIView.animate(
            withDuration: 0.3,
            delay: 0.05 * Double(indexPath.row),
            options: [.curveEaseInOut],
            animations: {
                cell.alpha = 1
                cell.transform = .identity
            }
        )
    }
    
    // Swipe actions: Restore / Delete permanently
    override func tableView(_ tableView: UITableView,
                            trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath
    ) -> UISwipeActionsConfiguration? {
        
        let deletedSinger = deletedSingers[indexPath.row]
        
        // Restore
        let restoreAction = UIContextualAction(style: .normal, title: "Restore") { [weak self] _, _, completionHandler in
            guard let self = self else { return }
            guard let cell = tableView.cellForRow(at: indexPath) else {
                completionHandler(false)
                return
            }
            let snapshot = cell.snapshotView(afterScreenUpdates: false)
            snapshot?.frame = cell.frame
            if let snap = snapshot {
                self.tableView.addSubview(snap)
            }
            
            if let _ = self.coreDataManager.restoreSinger(from: deletedSinger) {
                self.deletedSingers.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
                
                UIView.animate(withDuration: 0.5, animations: {
                    snapshot?.frame.origin.y -= 50
                    snapshot?.alpha = 0
                    snapshot?.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
                }, completion: { _ in
                    snapshot?.removeFromSuperview()
                    self.updateEmptyStateVisibility()
                    
                    let alert = UIAlertController(
                        title: "Restore Successful",
                        message: "The singer was successfully restored to the list.",
                        preferredStyle: .alert
                    )
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                })
            }
            completionHandler(true)
        }
        restoreAction.backgroundColor = .systemGreen
        restoreAction.image = UIImage(systemName: "arrow.uturn.left")
        
        // Permanently delete
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [weak self] _, _, completionHandler in
            guard let self = self else { return }
            
            let alert = UIAlertController(
                title: "Delete Permanently",
                message: "Are you sure you want to permanently delete this singer? This action cannot be undone.",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in
                completionHandler(false)
            })
            alert.addAction(UIAlertAction(title: "Delete", style: .destructive) { _ in
                guard let cell = tableView.cellForRow(at: indexPath) else {
                    completionHandler(true)
                    return
                }
                let snapshot = cell.snapshotView(afterScreenUpdates: false)
                snapshot?.frame = cell.frame
                if let snap = snapshot {
                    self.tableView.addSubview(snap)
                }
                
                self.coreDataManager.permanentlyDeleteSinger(deletedSinger: deletedSinger)
                self.deletedSingers.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
                
                UIView.animate(withDuration: 0.5, animations: {
                    snapshot?.alpha = 0
                    snapshot?.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
                }, completion: { _ in
                    snapshot?.removeFromSuperview()
                    self.updateEmptyStateVisibility()
                })
                completionHandler(true)
            })
            self.present(alert, animated: true)
        }
        deleteAction.image = UIImage(systemName: "trash.fill")
        
        return UISwipeActionsConfiguration(actions: [deleteAction, restoreAction])
    }
}
