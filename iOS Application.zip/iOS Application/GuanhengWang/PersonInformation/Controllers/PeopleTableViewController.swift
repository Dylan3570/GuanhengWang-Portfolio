import UIKit
import CoreData
import Photos
import PhotosUI  // Supports PHPicker to access iCloud photos

class PeopleTableViewController: UITableViewController,
                                UIImagePickerControllerDelegate,
                                UINavigationControllerDelegate,
                                PHPickerViewControllerDelegate {

    // MARK: - Properties
    
    var peopleData: People!
    var singers: [Singer] = []
    let coreDataManager = CoreDataManager.shared
    
    // Holds the singer (and its index) that is pending deletion but not yet confirmed
    private var pendingDeletionSinger: Singer?
    private var pendingDeletionIndexPath: IndexPath?
    
    // Image picker related
    private var selectedImage: UIImage?
    private var selectedImageName: String?
    
    // Temporarily store text data from the add/edit form
    private var tempName: String?
    private var tempAddress: String?
    private var tempPhone: String?
    
    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // If Core Data has no singers, load from the XML
        peopleData = People(fromXMLFile: "singers.xml")
        loadInitialDataIfNeeded()
        
        setupNavigationButtons()
        
        // Allow selection while in Edit mode so we can swipe
        tableView.allowsSelectionDuringEditing = true
        
        // Set up the gradient background and pull-to-refresh
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Fetch the latest singers each time the view appears
        fetchSingersFromCoreData()
    }
    
    // If no Singer records exist in Core Data, import from the XML
    private func loadInitialDataIfNeeded() {
        let existingCount = coreDataManager.fetchAllSingers().count
        if existingCount == 0 {
            for i in 0..<peopleData.getCount() {
                let person = peopleData.getPerson(index: i)
                coreDataManager.createSinger(
                    name: person.name,
                    address: person.address,
                    phone: person.phone,
                    image: person.image,
                    bioText: person.text,
                    websiteUrl: person.url
                )
            }
        }
    }
    
    // Fetch the current list of singers from Core Data
    private func fetchSingersFromCoreData() {
        singers = coreDataManager.fetchAllSingers()
        tableView.reloadData()
    }
    
    // MARK: - UI (gradient background + pull-to-refresh)
    
    private func setupUI() {
        // (1) Pink → light green gradient
        let backgroundGradient = CAGradientLayer()
        backgroundGradient.colors = [
            UIColor(red: 255/255, green: 160/255, blue: 180/255, alpha: 1.0).cgColor,
            UIColor(red: 160/255, green: 250/255, blue: 210/255, alpha: 1.0).cgColor
        ]
        backgroundGradient.startPoint = CGPoint(x: 0, y: 0)
        backgroundGradient.endPoint = CGPoint(x: 1, y: 1)
        backgroundGradient.frame = view.bounds
        
        let bgView = UIView(frame: view.bounds)
        bgView.layer.insertSublayer(backgroundGradient, at: 0)
        tableView.backgroundView = bgView
        
        // (2) Pull to refresh
        refreshControl = UIRefreshControl()
        refreshControl?.tintColor = UIColor(red: 255/255, green: 100/255, blue: 150/255, alpha: 1.0)
        refreshControl?.addTarget(self, action: #selector(refreshData), for: .valueChanged)
    }
    
    @objc private func refreshData() {
        UIView.animate(withDuration: 0.3) {
            self.tableView.alpha = 0.6
        } completion: { _ in
            self.fetchSingersFromCoreData()
            UIView.animate(withDuration: 0.3) {
                self.tableView.alpha = 1.0
            }
        }
        
        // Delay ending refresh for better visual feedback
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            self.refreshControl?.endRefreshing()
        }
    }
    
    // MARK: - Navigation Bar Buttons
    
    private func setupNavigationButtons() {
        // Right “+” button
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addButtonTapped)
        )
        
        // Left buttons: “Favorites” and “History”
        let favoritesButton = UIBarButtonItem(
            title: "Favorites",
            style: .plain,
            target: self,
            action: #selector(favoritesButtonTapped)
        )
        let historyButton = UIBarButtonItem(
            title: "History",
            style: .plain,
            target: self,
            action: #selector(historyButtonTapped)
        )
        navigationItem.leftBarButtonItems = [favoritesButton, historyButton]
        
        // Add an “Edit” button on the right
        navigationItem.rightBarButtonItems = [
            navigationItem.rightBarButtonItem!,
            self.editButtonItem
        ]
    }
    
    // “+” button
    @objc func addButtonTapped() {
        // Reset temporary data before adding
        selectedImage = nil
        selectedImageName = nil
        tempName = nil
        tempAddress = nil
        tempPhone = nil
        
        showSingerForm(title: "Add Singer", singer: nil)
    }
    
    @objc func favoritesButtonTapped() {
        performSegue(withIdentifier: "ShowFavorites", sender: nil)
    }
    
    @objc func historyButtonTapped() {
        performSegue(withIdentifier: "ShowDeleteHistory", sender: nil)
    }
    
    // MARK: - Add/Edit Singer Form
    
    private func showSingerForm(title: String, singer: Singer?) {
        let alert = UIAlertController(
            title: title,
            message: "Enter singer details",
            preferredStyle: .alert
        )
        
        // Name
        alert.addTextField { [weak self] textField in
            textField.placeholder = "Name"
            if let temp = self?.tempName, !temp.isEmpty {
                textField.text = temp
            } else {
                textField.text = singer?.name
            }
        }
        // Address
        alert.addTextField { [weak self] textField in
            textField.placeholder = "Address"
            if let temp = self?.tempAddress, !temp.isEmpty {
                textField.text = temp
            } else {
                textField.text = singer?.address
            }
        }
        // Phone
        alert.addTextField { [weak self] textField in
            textField.placeholder = "Phone"
            if let temp = self?.tempPhone, !temp.isEmpty {
                textField.text = temp
            } else {
                textField.text = singer?.phone
            }
        }
        
        // “Choose Photo” => store fields, then show image picker
        alert.addAction(UIAlertAction(title: "Choose Photo", style: .default) { [weak self] _ in
            guard let self = self else { return }
            
            // Save form data
            self.tempName = alert.textFields?[0].text
            self.tempAddress = alert.textFields?[1].text
            self.tempPhone = alert.textFields?[2].text
            
            // Dismiss alert => check permission => pick image
            self.dismiss(animated: true) {
                let editingSinger = singer
                let formTitle = title
                self.imagePickerDismissed = {
                    // After choosing an image, show the form again
                    DispatchQueue.main.async {
                        self.showSingerForm(title: formTitle, singer: editingSinger)
                    }
                }
                self.checkPhotoLibraryPermission()
            }
        })
        
        // “Cancel” => reset temp data
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { [weak self] _ in
            self?.tempName = nil
            self?.tempAddress = nil
            self?.tempPhone = nil
        })
        
        // “Add” or “Update”
        let actionTitle = (singer == nil) ? "Add" : "Update"
        alert.addAction(UIAlertAction(title: actionTitle, style: .default) { [weak self] _ in
            guard let self = self else { return }
            
            // Validate that fields are not empty
            guard let name = alert.textFields?[0].text, !name.isEmpty,
                  let address = alert.textFields?[1].text, !address.isEmpty,
                  let phone = alert.textFields?[2].text, !phone.isEmpty
            else {
                return
            }
            
            // Decide on the image name
            let imageName: String
            if let newImageName = self.selectedImageName {
                // If a new image was chosen
                imageName = newImageName
                if let selectedImg = self.selectedImage {
                    self.saveImage(selectedImg, name: newImageName)
                }
            } else if let existingImage = singer?.image, !existingImage.isEmpty {
                // In edit mode, keep the old image
                imageName = existingImage
            } else {
                // Use the default
                imageName = "default"
            }
            
            // Create or update
            if let existingSinger = singer {
                self.coreDataManager.updateSinger(
                    singer: existingSinger,
                    name: name,
                    address: address,
                    phone: phone,
                    image: imageName,
                    bioText: existingSinger.bioText ?? "",
                    websiteUrl: existingSinger.websiteUrl ?? ""
                )
            } else {
                self.coreDataManager.createSinger(
                    name: name,
                    address: address,
                    phone: phone,
                    image: imageName,
                    bioText: "",
                    websiteUrl: ""
                )
            }
            
            // Reset temp data
            self.selectedImage = nil
            self.selectedImageName = nil
            self.tempName = nil
            self.tempAddress = nil
            self.tempPhone = nil
            
            // Refresh
            self.fetchSingersFromCoreData()
        })
        
        present(alert, animated: true)
    }
    
    // MARK: - Image Picker
    
    private var imagePickerDismissed: (() -> Void)?
    
    private func checkPhotoLibraryPermission() {
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized, .limited:
            DispatchQueue.main.async {
                self.presentImagePicker()
            }
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { [weak self] newStatus in
                if newStatus == .authorized || newStatus == .limited {
                    DispatchQueue.main.async {
                        self?.presentImagePicker()
                    }
                }
            }
        default:
            DispatchQueue.main.async {
                let alert = UIAlertController(
                    title: "Unable to Access Photo Library",
                    message: "Please allow the app to access your photo library in Settings",
                    preferredStyle: .alert
                )
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                self.present(alert, animated: true)
            }
        }
    }
    
    private func presentImagePicker() {
        if #available(iOS 14, *) {
            var configuration = PHPickerConfiguration(photoLibrary: .shared())
            configuration.selectionLimit = 1
            configuration.filter = .images
            let picker = PHPickerViewController(configuration: configuration)
            picker.delegate = self
            present(picker, animated: true)
        } else {
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
                let picker = UIImagePickerController()
                picker.delegate = self
                picker.sourceType = .photoLibrary
                picker.allowsEditing = true
                present(picker, animated: true)
            } else {
                let alert = UIAlertController(
                    title: "Cannot Access Photo Library",
                    message: "Your device does not support accessing the local photo library",
                    preferredStyle: .alert
                )
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                present(alert, animated: true)
            }
        }
    }
    
    private func saveImage(_ image: UIImage, name: String) {
        guard let data = image.jpegData(compressionQuality: 0.8) else { return }
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documents.appendingPathComponent(name)
        do {
            try data.write(to: fileURL)
            print("Image saved to: \(fileURL.path)")
        } catch {
            print("Failed to save image: \(error)")
        }
    }
    
    private func loadImage(named imageName: String) -> UIImage? {
        // First, check the app's resource bundle
        if let image = UIImage(named: imageName) {
            return image
        }
        // Then check the Documents directory
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documents.appendingPathComponent(imageName)
        return UIImage(contentsOfFile: fileURL.path)
    }
    
    // MARK: - TableView DataSource / Delegate
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return singers.count
    }
    
    func configureCell(_ cell: UITableViewCell) {
        // Make the cell and contentView transparent
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear
        
        // Create the gradient layer
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 160/255, blue: 180/255, alpha: 1.0).cgColor,
            UIColor(red: 160/255, green: 250/255, blue: 210/255, alpha: 1.0).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        
        // Use contentView.bounds for the initial frame
        gradientLayer.frame = cell.contentView.bounds
        
        // Remove any existing gradient layer
        if let oldLayer = cell.contentView.layer.sublayers?.first(where: { $0 is CAGradientLayer }) {
            oldLayer.removeFromSuperlayer()
        }
        cell.contentView.layer.insertSublayer(gradientLayer, at: 0)
        
        // **Revert to the original green style**
        cell.textLabel?.textColor = UIColor(red: 100/255, green: 180/255, blue: 150/255, alpha: 1.0)
        cell.textLabel?.font = UIFont.italicSystemFont(ofSize: 20)
        
        cell.detailTextLabel?.textColor = UIColor(red: 80/255, green: 150/255, blue: 130/255, alpha: 1.0)
        cell.detailTextLabel?.font = UIFont.italicSystemFont(ofSize: 14)
        
        // Round corners for the image
        cell.imageView?.layer.cornerRadius = 15
        cell.imageView?.layer.masksToBounds = true
        cell.imageView?.layer.borderWidth = 2
        cell.imageView?.layer.borderColor = UIColor(white: 1.0, alpha: 0.6).cgColor
        
        // Add shadow and corner radius to the cell
        cell.layer.cornerRadius = 18
        cell.layer.masksToBounds = false
        cell.layer.shadowColor = UIColor.black.cgColor
        cell.layer.shadowOpacity = 0.08
        cell.layer.shadowOffset = CGSize(width: 4, height: 4)
        cell.layer.shadowRadius = 6
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        configureCell(cell)
        
        let singer = singers[indexPath.row]
        cell.textLabel?.text = singer.name
        cell.detailTextLabel?.text = singer.phone
        
        if let imageName = singer.image, !imageName.isEmpty {
            cell.imageView?.image = loadImage(named: imageName) ?? UIImage(named: "default")
        } else {
            cell.imageView?.image = UIImage(named: "default")
        }
        
        return cell
    }
    
    // Deselect immediately after selecting
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    // Ensure the gradient covers the entire cell + entrance animation
    override func tableView(_ tableView: UITableView,
                            willDisplay cell: UITableViewCell,
                            forRowAt indexPath: IndexPath) {
        if let gradientLayer = cell.contentView.layer.sublayers?.first(where: { $0 is CAGradientLayer }) as? CAGradientLayer {
            gradientLayer.frame = cell.contentView.bounds
        }
        
        // Entrance animation (similar to DeletedSingersViewController)
        cell.alpha = 0
        cell.transform = CGAffineTransform(translationX: 0, y: 20)
        
        UIView.animate(
            withDuration: 0.3,
            delay: 0.05 * Double(indexPath.row),
            options: [.curveEaseInOut],
            animations: {
                cell.alpha = 1
                cell.transform = .identity
            }
        )
    }
    
    // MARK: - Editing / Deletion
    
    // Allow deletion in edit mode
    override func tableView(_ tableView: UITableView,
                            editingStyleForRowAt indexPath: IndexPath
    ) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    // "Undoable" delete: remove from UI, prompt, then confirm soft-delete or undo
    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCell.EditingStyle,
                            forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // 1. Temporarily remove the singer from the UI, but do not soft delete yet
            let singer = singers[indexPath.row]
            pendingDeletionSinger = singer
            pendingDeletionIndexPath = indexPath
            
            // Remove from array and UI
            singers.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            
            // 2. Show an alert: "Singer Deleted / Singer was moved to history"
            let alert = UIAlertController(
                title: "Singer Deleted",
                message: "\(singer.name ?? "Singer") was moved to history",
                preferredStyle: .alert
            )
            
            // [Undo] => cancel delete and re-insert the data
            alert.addAction(UIAlertAction(title: "Undo", style: .default) { [weak self] _ in
                guard let self = self,
                      let undoneSinger = self.pendingDeletionSinger,
                      let undoneIndex = self.pendingDeletionIndexPath else { return }
                
                self.singers.insert(undoneSinger, at: undoneIndex.row)
                tableView.insertRows(at: [undoneIndex], with: .fade)
                
                // Clear
                self.pendingDeletionSinger = nil
                self.pendingDeletionIndexPath = nil
            })
            
            // [OK] => perform the actual soft delete
            alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
                guard let self = self,
                      let realSingerToDelete = self.pendingDeletionSinger else { return }
                
                // Now do the soft delete
                self.coreDataManager.softDeleteSinger(singer: realSingerToDelete)
                
                // Clear
                self.pendingDeletionSinger = nil
                self.pendingDeletionIndexPath = nil
            })
            
            self.present(alert, animated: true)
        }
    }
    
    // Add an "Edit" action in the leading swipe direction
    override func tableView(_ tableView: UITableView,
                            leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath
    ) -> UISwipeActionsConfiguration? {
        let editAction = UIContextualAction(style: .normal, title: "Edit") { [weak self] _, _, completionHandler in
            guard let self = self else { return }
            
            // Reset temp data before editing
            self.selectedImage = nil
            self.selectedImageName = nil
            self.tempName = nil
            self.tempAddress = nil
            self.tempPhone = nil
            
            self.showSingerForm(title: "Edit Singer", singer: self.singers[indexPath.row])
            completionHandler(true)
        }
        editAction.backgroundColor = .systemBlue
        
        return UISwipeActionsConfiguration(actions: [editAction])
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue2" {
            if let cell = sender as? UITableViewCell,
               let indexPath = tableView.indexPath(for: cell) {
                
                let singer = singers[indexPath.row]
                let destination = segue.destination as! PersonViewController
                destination.singer = singer
                
                // For compatibility with older Person structures, optionally do:
                if indexPath.row < peopleData.getCount() {
                    destination.personData = peopleData.getPerson(index: indexPath.row)
                }
            }
        } else if segue.identifier == "ShowFavorites" {
            // No extra data needed
        } else if segue.identifier == "ShowDeleteHistory" {
            // DeletedSingersViewController will fetch data from CoreDataManager
        }
    }
    
    // MARK: - UIImagePickerControllerDelegate
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let editedImage = info[.editedImage] as? UIImage {
            selectedImage = editedImage
        } else if let originalImage = info[.originalImage] as? UIImage {
            selectedImage = originalImage
        }
        
        // Give the image a unique name
        selectedImageName = "singer_\(Date().timeIntervalSince1970).jpg"
        
        picker.dismiss(animated: true) { [weak self] in
            self?.imagePickerDismissed?()
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true) { [weak self] in
            self?.imagePickerDismissed?()
        }
    }
    
    // MARK: - PHPickerViewControllerDelegate
    
    @available(iOS 14, *)
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true) { [weak self] in
            guard let self = self else { return }
            
            guard let result = results.first else {
                self.imagePickerDismissed?()
                return
            }
            
            result.itemProvider.loadObject(ofClass: UIImage.self) { object, error in
                if let image = object as? UIImage {
                    DispatchQueue.main.async {
                        self.selectedImage = image
                        self.selectedImageName = "singer_\(Date().timeIntervalSince1970).jpg"
                        self.imagePickerDismissed?()
                    }
                } else {
                    print("Unable to load image: \(error?.localizedDescription ?? "Unknown error")")
                    DispatchQueue.main.async {
                        self.imagePickerDismissed?()
                    }
                }
            }
        }
    }
}
