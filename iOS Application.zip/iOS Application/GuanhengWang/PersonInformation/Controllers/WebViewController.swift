import UIKit
import WebKit
import CoreData

class WebViewController: UIViewController {
    @IBOutlet weak var titleView: UILabel!
    @IBOutlet weak var personWebView: WKWebView!
    
    var urlData: String?
    var personData: Person?
    var singer: Singer?  // Add this new property for CoreData

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        loadWebContent()
    }
    
    private func loadWebContent() {
        // Determine which URL to use - from CoreData Singer or from personData
        var urlString: String?
        
        if let singer = singer, let websiteUrl = singer.websiteUrl, !websiteUrl.isEmpty {
            urlString = websiteUrl
        } else if let urlFromData = urlData, !urlFromData.isEmpty {
            urlString = urlFromData
        }
        
        // Load the URL if we have one
        if let urlString = urlString, let url = URL(string: urlString) {
            let request = URLRequest(url: url)
            personWebView.load(request)
        } else {
            print("URL is nil or invalid")
            // Maybe show a message in the web view that no URL is available
            let noUrlMessage = "<html><body style='font-family: -apple-system; text-align: center; padding: 40px;'><h2>No website URL available</h2></body></html>"
            personWebView.loadHTMLString(noUrlMessage, baseURL: nil)
        }
    }

    func setupUI() {
        addGradientBackground()
        
        titleView.backgroundColor = UIColor(red: 255/255, green: 230/255, blue: 240/255, alpha: 0.9)
        titleView.layer.cornerRadius = 20
        titleView.layer.masksToBounds = true
        titleView.textAlignment = .center
        titleView.font = UIFont.italicSystemFont(ofSize: 24)
        titleView.textColor = UIColor(red: 50/255, green: 120/255, blue: 100/255, alpha: 1.0)
        
        personWebView.layer.cornerRadius = 16
        personWebView.layer.masksToBounds = true
        personWebView.layer.borderWidth = 1
        personWebView.layer.borderColor = UIColor(white: 1.0, alpha: 0.7).cgColor
        personWebView.layer.shadowColor = UIColor.black.cgColor
        personWebView.layer.shadowOpacity = 0.1
        personWebView.layer.shadowOffset = CGSize(width: 3, height: 3)
        personWebView.layer.shadowRadius = 6
    }

    func addGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 200/255, blue: 220/255, alpha: 1.0).cgColor,
            UIColor(red: 140/255, green: 220/255, blue: 190/255, alpha: 1.0).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds

        if view.layer.sublayers?.contains(where: { $0 is CAGradientLayer }) == false {
            view.layer.insertSublayer(gradientLayer, at: 0)
        }
    }
}
