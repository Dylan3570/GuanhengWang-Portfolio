import CoreData
import Foundation

class CoreDataManager {
    static let shared = CoreDataManager() // Singleton
    
    // MARK: - Core Data Stack
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "SingerModel")
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
        return container
    }()
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    // MARK: - Core Data Saving Support
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    // MARK: - Singer Operations
    
    func fetchAllSingers() -> [Singer] {
        let request: NSFetchRequest<Singer> = Singer.fetchRequest()
        
        do {
            return try context.fetch(request)
        } catch {
            print("Error fetching singers: \(error)")
            return []
        }
    }
    
    func createSinger(name: String,
                      address: String,
                      phone: String,
                      image: String,
                      bioText: String,
                      websiteUrl: String) -> Singer {
        
        let singer = Singer(context: context)
        singer.name = name
        singer.address = address
        singer.phone = phone
        singer.image = image
        singer.bioText = bioText
        singer.websiteUrl = websiteUrl
        
        saveContext()
        return singer
    }
    
    func updateSinger(singer: Singer,
                      name: String,
                      address: String,
                      phone: String,
                      image: String,
                      bioText: String,
                      websiteUrl: String) {
        
        singer.name = name
        singer.address = address
        singer.phone = phone
        singer.image = image
        singer.bioText = bioText
        singer.websiteUrl = websiteUrl
        
        saveContext()
    }
    
    // Changed to call the softDeleteSinger method instead of directly deleting
    func deleteSinger(singer: Singer) {
        softDeleteSinger(singer: singer)
    }
    
    // MARK: - Soft-Delete Operations
    
    // Soft-delete a singer (move to deleted history)
    func softDeleteSinger(singer: Singer) {
        // 1. Create a DeletedSinger object
        let deletedSinger = DeletedSinger(context: context)
        
        // 2. Copy properties
        deletedSinger.id = singer.name // Use the singer's name as the ID
        deletedSinger.name = singer.name
        deletedSinger.address = singer.address
        deletedSinger.phone = singer.phone
        deletedSinger.image = singer.image
        deletedSinger.bioText = singer.bioText
        deletedSinger.websiteUrl = singer.websiteUrl
        deletedSinger.deletionDate = Date()
        
        // 3. Delete the original Singer
        context.delete(singer)
        
        // 4. Save changes
        saveContext()
    }
    
    // Fetch all deleted history
    func fetchAllDeletedSingers() -> [DeletedSinger] {
        let request: NSFetchRequest<DeletedSinger> = DeletedSinger.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "deletionDate", ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("Error fetching deleted singers: \(error)")
            return []
        }
    }
    
    // Restore a singer from deleted history
    func restoreSinger(from deletedSinger: DeletedSinger) -> Singer? {
        // 1. Create a new Singer object
        let singer = Singer(context: context)
        
        // 2. Copy properties
        singer.name = deletedSinger.name
        singer.address = deletedSinger.address
        singer.phone = deletedSinger.phone
        singer.image = deletedSinger.image
        singer.bioText = deletedSinger.bioText
        singer.websiteUrl = deletedSinger.websiteUrl
        
        // 3. Remove the DeletedSinger record
        context.delete(deletedSinger)
        
        // 4. Save changes
        saveContext()
        
        return singer
    }
    
    // Permanently delete a previously deleted singer
    func permanentlyDeleteSinger(deletedSinger: DeletedSinger) {
        context.delete(deletedSinger)
        saveContext()
    }
    
    // Clear all deleted history
    func clearAllDeletedSingers() {
        let request: NSFetchRequest<DeletedSinger> = DeletedSinger.fetchRequest()
        
        do {
            let results = try context.fetch(request)
            for deletedSinger in results {
                context.delete(deletedSinger)
            }
            saveContext()
        } catch {
            print("Error clearing deleted singers: \(error)")
        }
    }
    
    // Fetch a deleted singer by ID
    func getDeletedSingerByID(singerID: String) -> DeletedSinger? {
        let request: NSFetchRequest<DeletedSinger> = DeletedSinger.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", singerID)
        
        do {
            let results = try context.fetch(request)
            return results.first
        } catch {
            print("Error fetching deleted singer by ID: \(error)")
            return nil
        }
    }
    
    // MARK: - Favorites Operations
    
    func fetchAllFavorites() -> [Favorite] {
        let request: NSFetchRequest<Favorite> = Favorite.fetchRequest()
        
        do {
            return try context.fetch(request)
        } catch {
            print("Error fetching favorites: \(error)")
            return []
        }
    }
    
    func isSingerInFavorites(singerID: String) -> Bool {
        let request: NSFetchRequest<Favorite> = Favorite.fetchRequest()
        request.predicate = NSPredicate(format: "singerID == %@", singerID)
        
        do {
            let results = try context.fetch(request)
            return !results.isEmpty
        } catch {
            print("Error checking if singer is favorite: \(error)")
            return false
        }
    }
    
    func addSingerToFavorites(name: String,
                              singerID: String,
                              address: String,
                              phone: String,
                              image: String) {
        
        // First check if this favorite already exists
        if isSingerInFavorites(singerID: singerID) {
            return
        }
        
        let favorite = Favorite(context: context)
        favorite.singerID = singerID
        favorite.name = name
        favorite.address = address
        favorite.phone = phone
        favorite.image = image
        favorite.dateAdded = Date()
        
        saveContext()
    }
    
    func removeSingerFromFavorites(singerID: String) {
        let request: NSFetchRequest<Favorite> = Favorite.fetchRequest()
        request.predicate = NSPredicate(format: "singerID == %@", singerID)
        
        do {
            let results = try context.fetch(request)
            for favorite in results {
                context.delete(favorite)
            }
            saveContext()
        } catch {
            print("Error removing singer from favorites: \(error)")
        }
    }
    
    func clearAllFavorites() {
        let request: NSFetchRequest<Favorite> = Favorite.fetchRequest()
        
        do {
            let results = try context.fetch(request)
            for favorite in results {
                context.delete(favorite)
            }
            saveContext()
        } catch {
            print("Error clearing all favorites: \(error)")
        }
    }
    
    // MARK: - XML Parsing and Initial Data Loading
    
    func loadInitialDataFromXML(xmlData: Data) {
        // Check if there's already data
        let singerCount = try? context.count(for: Singer.fetchRequest())
        if singerCount ?? 0 > 0 {
            // Data already exists, do not load
            return
        }
        
        // Parse XML and create initial data
        parseXMLAndCreateSingers(xmlData: xmlData)
    }
    
    private func parseXMLAndCreateSingers(xmlData: Data) {
        // The actual parsing logic will call your XMLPeopleParser here
        let parser = XMLPeopleParser(name: "singers.xml")
        parser.parsing()
    }
    
    // Fetch a singer by a specific ID
    func getSingerByID(singerID: String) -> Singer? {
        let request: NSFetchRequest<Singer> = Singer.fetchRequest()
        request.predicate = NSPredicate(format: "name == %@", singerID)
        
        do {
            let results = try context.fetch(request)
            return results.first
        } catch {
            print("Error fetching singer by ID: \(error)")
            return nil
        }
    }
    
    // MARK: - Batch Operations
    
    // Restore all deleted singers
    func restoreAllDeletedSingers() -> Int {
        let deletedSingers = fetchAllDeletedSingers()
        var restoredCount = 0
        
        for deletedSinger in deletedSingers {
            if restoreSinger(from: deletedSinger) != nil {
                restoredCount += 1
            }
        }
        
        return restoredCount
    }
    
    // Restore a batch of selected deleted singers
    func restoreSelectedDeletedSingers(deletedSingers: [DeletedSinger]) -> Int {
        var restoredCount = 0
        
        for deletedSinger in deletedSingers {
            if restoreSinger(from: deletedSinger) != nil {
                restoredCount += 1
            }
        }
        
        return restoredCount
    }
}
